//
//  ViewController.h
//  BlinkCard-Sample-ObjC
//
//  Created by Jure Čular on 4/11/19.
//  Copyright © 2019 Microblink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

